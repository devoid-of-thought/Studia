    close all
    std1ID = "280082"
    std2ID = "280141"
    A = str2num(extract(std1ID,6))
    B = str2num(extract(std2ID,6))
    C = A + B
    syms x(t) s 
    tspan = 0 : 0.01 : 300;
   
     
    function dydt = roz(t, y, A, B, C)
    dydt = zeros(2,1);
    dydt(1) = y(2);
    dydt(2) = (A + sin(B*t) - (1/C)*y(2) - 2*y(1)) / 5;
    end
    X0 = [0 0];    
    
    X1= [2 1];
    
    X2 = [5 9];
    
    X3 = [3 4]
    k = ode45(@(t,x) roz(t, x, A, B, C), tspan, X0);
    
    [t, X] = ode45(@(t,x) roz(t, x, A, B, C), tspan, X0);
    figure(1)
    plot(t, X(:,1))
    grid on;
    xlabel('Czas [s]');
    ylabel('Wartość sygnału');
    
    [t, X] = ode45(@(t,x) roz(t,x,A,B,C), tspan, X1);
    
    figure(2)
    plot(t, X(:,1))
    grid on;
    xlabel('Czas [s]');
    ylabel('Wartość sygnału');
    [t, X] = ode45(@(t,x) roz(t,x,A,B,C), tspan, X2);
    
    figure(3)
    plot(t, X(:,1))
    grid on;
    xlabel('Czas [s]');
    ylabel('Wartość sygnału');
    
    [t, X] = ode45(@(t,x) roz(t,x,A,B,C), tspan, X3);
    
    figure(4)
    plot(t, X(:,1))
    grid on;
    xlabel('Czas [s]');
    ylabel('Wartość sygnału');
    
    tspan2 = 0 : 1 : 300
    [t, X] = ode45(@(t,x) roz(t,x,A,B,C), tspan2, X3);

    figure(5)
    plot(t, X(:,1))
    grid on;
    xlabel('Czas [s]');
    ylabel('Wartość sygnału');
    tspan3 = 0 : 10 : 300
    [t, X] = ode45(@(t,x) roz(t,x,A,B,C), tspan3, X3);

    figure(6)
    plot(t, X(:,1))
    grid on;
    xlabel('Czas [s]');
    ylabel('Wartość sygnału');
    
    tspan = 0 : 0.1 : 300
    [t, X] = ode45(@(t,x) roz(t,x,A,B,C), tspan, X3);

    anal =(167.*exp(-t/30).*(cos((359^(1/2)*t)/30) + (10817*359^(1/2)*sin((359^(1/2)*t)/30))/59953))/82 - (27*sin(t))/82 - (3*cos(t))/82 + 1;   
        
    figure(7)

    plot(t, X(:,1), 'b-',"LineWidth",0.25)
    hold on
    plot(t, anal, 'r-',"LineWidth",0.25)  
    grid on;
    xlabel('Czas [s]');
    ylabel('Wartość sygnału');
    hold off




    
    